# DO NOT WRITE ANY MAGIC COMMENT HERE.
def default_src_encoding
  return __ENCODING__
end
