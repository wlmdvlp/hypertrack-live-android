warn "requiring rdoc/markup/inline is deprecated and will be removed in RDoc 4." if $-w
